package com.yourname.browsermod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.awt.Desktop;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

public class BrowserMod implements ClientModInitializer {
    private static BrowserScreen browserScreen;
    public static KeyBinding openBrowserKey;
    
    @Override
    public void onInitializeClient() {
        openBrowserKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.browsermod.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_BRACKET, "category.browsermod.general"
        ));
        
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openBrowserKey.wasPressed()) {
                if (browserScreen == null || client.currentScreen != browserScreen) {
                    browserScreen = new BrowserScreen();
                }
                client.setScreen(browserScreen);
            }
        });
    }
    
    public static class BrowserScreen extends Screen {
        private int x = 50, y = 50, width = 800, height = 600;
        private boolean dragging = false, resizing = false;
        private int dragX, dragY;
        private String currentUrl = "https://www.youtube.com";
        private TextFieldWidget urlField;
        private List<Bookmark> bookmarks = new ArrayList<>();
        
        private static class Bookmark { String name, url; Bookmark(String n, String u) { name = n; url = u; } }
        
        public BrowserScreen() {
            super(Text.literal("Browser"));
            bookmarks.add(new Bookmark("📺 YouTube", "https://youtube.com"));
            bookmarks.add(new Bookmark("📹 Twitch", "https://twitch.tv"));
            bookmarks.add(new Bookmark("🎵 Spotify", "https://spotify.com"));
        }
        
        @Override
        protected void init() {
            addDrawableChild(ButtonWidget.builder(Text.literal("✕"), b -> close()).dimensions(x + width - 25, y + 3, 20, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("⣿"), b -> {}).dimensions(x + 5, y + 3, 20, 20).build());
            
            urlField = new TextFieldWidget(textRenderer, x + 30, y + 5, 300, 16, Text.literal("URL"));
            urlField.setText(currentUrl);
            urlField.setMaxLength(200);
            addSelectableChild(urlField);
            
            addDrawableChild(ButtonWidget.builder(Text.literal("Go"), b -> {
                currentUrl = urlField.getText();
                try { Desktop.getDesktop().browse(new URI(currentUrl.startsWith("http") ? currentUrl : "https://" + currentUrl)); } 
                catch (Exception e) {}
            }).dimensions(x + 335, y + 3, 30, 18).build());
        }
        
        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            context.fill(x, y, x + width, y + height, 0xCC111122);
            context.fill(x, y, x + width, y + 25, 0xFF333344);
            context.drawBorder(x, y, width, height, 0xFFFFFFFF);
            context.drawText(textRenderer, "🌐 Browser", x + 30, y + 7, 0xFFFFFFAA, true);
            urlField.render(context, mouseX, mouseY, delta);
            
            int by = y + 40;
            for (int i = 0; i < bookmarks.size(); i++) {
                Bookmark b = bookmarks.get(i);
                int bx = x + 10 + (i % 3) * 110;
                context.fill(bx, by, bx + 100, by + 20, 0xAA444455);
                context.drawBorder(bx, by, 100, 20, 0xFF888888);
                context.drawText(textRenderer, b.name, bx + 5, by + 5, 0xFFFFFFFF, true);
            }
            super.render(context, mouseX, mouseY, delta);
        }
        
        @Override
        public boolean mouseClicked(double mx, double my, int button) {
            int by = y + 40;
            for (int i = 0; i < bookmarks.size(); i++) {
                Bookmark b = bookmarks.get(i);
                int bx = x + 10 + (i % 3) * 110;
                if (mx >= bx && mx <= bx + 100 && my >= by && my <= by + 20) {
                    try { Desktop.getDesktop().browse(new URI(b.url)); } catch (Exception e) {}
                    return true;
                }
            }
            
            if (mx >= x && mx <= x + width - 50 && my >= y && my <= y + 25) {
                dragging = true; dragX = (int)mx - x; dragY = (int)my - y; return true;
            }
            if (mx >= x + width - 15 && my >= y + height - 15) { resizing = true; return true; }
            return super.mouseClicked(mx, my, button);
        }
        
        @Override
        public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
            if (dragging) { x = (int)mx - dragX; y = (int)my - dragY; updateWidgetPositions(); return true; }
            if (resizing) { width = Math.max(300, (int)mx - x); height = Math.max(200, (int)my - y); updateWidgetPositions(); return true; }
            return super.mouseDragged(mx, my, button, dx, dy);
        }
        
        @Override
        public boolean mouseReleased(double mx, double my, int button) { dragging = false; resizing = false; return super.mouseReleased(mx, my, button); }
        
        private void updateWidgetPositions() { clearChildren(); init(); }
        @Override public boolean shouldPause() { return false; }
        @Override public boolean keyPressed(int key, int scan, int mod) { if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; } return super.keyPressed(key, scan, mod); }
    }
}